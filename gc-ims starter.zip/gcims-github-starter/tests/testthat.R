library(testthat); test_check('gcims')
