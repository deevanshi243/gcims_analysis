# Data directory

- Place **raw** GC-IMS files under `data/raw/` (not committed).
- Intermediate files go to `data/interim/`, processed/clean data to `data/processed/`.
- Do NOT commit large/sensitive data. Provide a small public sample in a separate `sample/` folder if needed.
